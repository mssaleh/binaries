## Module <inventory_barcode_scanning>

#### 13.10.2020
#### Version 14.0.1.0.0
#### ADD
Initial commit for Barcode scanning in Inventory


