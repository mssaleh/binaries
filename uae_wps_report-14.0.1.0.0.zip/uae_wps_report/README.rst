======================
Wage Protection System
======================
The Wages Protection System(WPS) is an electronic system
implemented by the GCC Countries to enable transparent Wage
Payment.This System Generates a Salary InformationFile(SIF).
And this file is acceptable by the Ministry Of Labour.
Tech
====
* [Python] - Models
* [XML] - Odoo views

Installation
============
- www.odoo.com/documentation/13.0/setup/install.html
- Install our custom addon

Developer: Nishad @Cybrosys
           V14: Muhammed Nafih @Cybrosys

Bug Tracker
===========
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Credits
=======
* Cybrosys Techno Solutions <https://www.cybrosys.com>

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.

